/* #undef SDL_VENDOR_INFO */
#define SDL_REVISION_NUMBER 0

#ifdef SDL_VENDOR_INFO
#define SDL_REVISION "SDL-2.33.0-g79992d69 (" SDL_VENDOR_INFO ")"
#else
#define SDL_REVISION "SDL-2.33.0-g79992d69"
#endif
